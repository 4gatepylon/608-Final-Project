//
// Entry point for person detection
//

#ifndef ELOQUENTTINYML_PERSON_DETECTION_H
#define ELOQUENTTINYML_PERSON_DETECTION_H

#include "../tensorflow.h"
#include "./common/models/person_detection/PersonDetection.h"

#endif //ELOQUENTTINYML_PERSON_DETECTION_H
