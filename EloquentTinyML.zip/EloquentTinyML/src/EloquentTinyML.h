/**
 * Eloquent interface to TinyML
 *  - TensorFlow
 *
 * Created by Simone Salerno <eloquentarduino@gmail.com>
 */
